﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Object.Model;

namespace WindowsFormsApplication1.Dynamics
{
    class InfluenceModel
    {
        
        List<Influence> influences = new List<Influence>(1);
    
        //public void InRelation(Cat a, Help b, int c)
        //{

        //}

        public void ComputeTimeFrame()
        {
            foreach (Influence influence in influences)
            {

            }
        }
    }

    class Influence
    {
        Influence(int type)
        {
        }
    }
}
